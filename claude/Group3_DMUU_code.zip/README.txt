Group 3 - DMUU assignment code.  Run:  python dmuu_assignment.py --part all   (parts 1..6, or --fast for a quick test)
Needs numpy, scipy>=1.9, pandas, matplotlib (cvxpy optional). Tables -> output/*.csv, figures -> output/*.png.
Base seed for all simulations = 1000*3+3 = 3003 (instances use seeds 3001..3010).
